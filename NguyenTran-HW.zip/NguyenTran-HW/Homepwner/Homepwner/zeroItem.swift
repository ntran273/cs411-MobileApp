//
//  zeroItem.swift
//  Homepwner
//
//  Created by Nguyen Tran on 4/7/18.
//  Copyright © 2018 Nguyen Tran. All rights reserved.
//
import UIKit

class zeroItem: NSObject {
    let name: String
    
    init(name: String) {
        self.name = name
        
        super.init()
    }
}
